<?php
/**
 * Footer idéntico a Astro para Winston & Harry
 */
?>
        </div><!-- .container -->
    </div><!-- #content -->

    <footer id="footer" class="footer">
        <!-- Barra Newsletter -->
        <div class="footer-newsletter-bar">
            <div class="container newsletter-container">
                <div class="newsletter-left">
                    <span class="newsletter-text">SUSCRÍBETE Y OBTÉN 10% DE DESCUENTO</span>
                    <button id="newsletter-toggle" class="newsletter-button">SUSCRIBIRME</button>
                </div>
                <div class="newsletter-social">
                    <a href="#" class="social-square" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" class="social-square" aria-label="TikTok"><i class="fa-brands fa-tiktok"></i></a>
                    <a href="#" class="social-square" aria-label="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
                    <a href="#" class="social-square" aria-label="Threads"><i class="fa-brands fa-threads"></i></a>
                </div>
            </div>

            <!-- Formulario Suscripción Acordeón -->
            <div id="newsletter-form-container" class="newsletter-form-container">
                <div class="container">
                    <form id="subscribe-form" class="subscribe-form">
                        <div class="form-grid">
                            <div class="form-group">
                                <label for="reg-email">Correo Electrónico *</label>
                                <input type="email" id="reg-email" name="email" required placeholder="tu@email.com">
                            </div>
                            <div class="form-group">
                                <label for="reg-phone">Número de teléfono móvil *</label>
                                <input type="tel" id="reg-phone" name="phone" required placeholder="+57 --- --- ----">
                            </div>
                            <div class="form-group">
                                <label for="reg-fname">Nombre *</label>
                                <input type="text" id="reg-fname" name="first_name" required placeholder="Tu nombre">
                            </div>
                            <div class="form-group">
                                <label for="reg-lname">Apellido *</label>
                                <input type="text" id="reg-lname" name="last_name" required placeholder="Tu apellido">
                            </div>
                        </div>
                        <div class="form-checkbox">
                            <input type="checkbox" id="reg-privacy" name="privacy" required>
                            <label for="reg-privacy">Autorizo el tratamiento de mis datos personales teniendo en cuenta la Política de Tratamiento de Datos de Winston & Harry. Aplican T&C</label>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="form-submit">ENVIAR</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="container footer-grid">
            <!-- Columna 1: Logo e Info -->
            <div class="footer-column brand-info">
                <div class="footer-logo">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="logo">
                        <img src="https://tienda.winstonandharrystore.com/wp-content/uploads/2020/12/logo-w-h-vertical.png" 
                             alt="Winston & Harry Logo" 
                             width="400" 
                             height="400" 
                             style="width: 250px !important; height: auto !important; display: block !important;" 
                             loading="lazy" 
                             referrerpolicy="no-referrer">
                    </a>
                </div>
                <p class="brand-description">
                    Nuestros productos son orgullosamente hechos a mano, cuidando las tradiciones que nuestros artesanos colombianos han conservado a lo largo de varias generaciones.
                </p>
                <div class="brand-contact">
                    <p><a href="https://winstonandharrystore.com/contacto" class="contact-link">Bogotá, Colombia</a></p>
                    <p>Teléfono: <a href="tel:+573103075540" class="contact-link">+57 310 3075540</a></p>
                    <p><a href="mailto:info@winstonandharrystore.com" class="contact-link">info@winstonandharrystore.com</a></p>
                </div>
            </div>

            <!-- Columna 2: Atención al Cliente -->
            <div class="footer-column">
                <h3 class="footer-title">ATENCIÓN AL CLIENTE</h3>
                <?php
                wp_nav_menu( array(
                    'menu'           => 44,
                    'theme_location' => 'footer_atencion',
                    'container'      => false,
                    'menu_class'     => 'footer-links',
                    'fallback_cb'    => false,
                ) );
                ?>
            </div>

            <!-- Columna 3: Nosotros -->
            <div class="footer-column">
                <h3 class="footer-title">NOSOTROS</h3>
                <?php
                wp_nav_menu( array(
                    'menu'           => 959,
                    'theme_location' => 'footer_nosotros',
                    'container'      => false,
                    'menu_class'     => 'footer-links',
                    'fallback_cb'    => false,
                ) );
                ?>
            </div>

            <!-- Columna 4: Legal -->
            <div class="footer-column">
                <h3 class="footer-title">LEGAL</h3>
                <?php
                wp_nav_menu( array(
                    'menu'           => 960,
                    'theme_location' => 'footer_legal',
                    'container'      => false,
                    'menu_class'     => 'footer-links',
                    'fallback_cb'    => false,
                ) );
                ?>
            </div>
        </div>

        <!-- Barra Inferior -->
        <div class="footer-bottom">
            <div class="container">
                <p>
                    WINSTON & HARRY 2026 UN DESARROLLO DE <a href="https://goestrategiacreativa.com/" target="_blank" class="agency">GO Agency.</a>
                </p>
            </div>
        </div>

        <!-- Botón Volver Arriba -->
        <button id="scroll-to-top" class="scroll-top-btn" aria-label="Volver arriba">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m18 15-6-6-6 6"></path></svg>
        </button>
    </footer>

    <?php wp_footer(); ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Toggle Newsletter
            const newsletterToggle = document.getElementById("newsletter-toggle");
            const newsletterForm = document.getElementById("newsletter-form-container");

            if (newsletterToggle && newsletterForm) {
                newsletterToggle.addEventListener("click", () => {
                    newsletterForm.classList.toggle("open");
                    newsletterToggle.textContent = newsletterForm.classList.contains("open") ? "CERRAR" : "SUSCRIBIRME";
                });
            }

            // Scroll to top
            const scrollBtn = document.getElementById("scroll-to-top");
            if (scrollBtn) {
                window.addEventListener("scroll", () => {
                    if (window.pageYOffset > 300) {
                        scrollBtn.classList.add("visible");
                    } else {
                        scrollBtn.classList.remove("visible");
                    }
                });
                scrollBtn.addEventListener("click", () => {
                    window.scrollTo({ top: 0, behavior: "smooth" });
                });
            }
        });
    </script>
</body>
</html>