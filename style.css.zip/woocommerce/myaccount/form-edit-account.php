<?php
/**
 * Edit account form
 * 
 * Winston & Harry Custom Template
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/form-edit-account.php.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 7.0.1
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_edit_account_form' ); ?>

<div class="account-form-wrapper">
    <div class="account-form-card">
        
        <h2>Detalles de la Cuenta</h2>
        <span class="subtitle">Actualiza tu información personal y mantén tu cuenta segura.</span>

        <form class="woocommerce-EditAccountForm edit-account" action="" method="post" <?php do_action( 'woocommerce_edit_account_form_tag' ); ?> >

            <?php do_action( 'woocommerce_edit_account_form_start' ); ?>

            <div class="name-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                <p class="woocommerce-form-row woocommerce-form-row--first form-row form-row-first">
                    <label for="account_first_name"><?php esc_html_e( 'Nombre', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
                    <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="account_first_name" id="account_first_name" autocomplete="given-name" value="<?php echo esc_attr( $user->first_name ); ?>" placeholder="Tu nombre" />
                </p>
                <p class="woocommerce-form-row woocommerce-form-row--last form-row form-row-last">
                    <label for="account_last_name"><?php esc_html_e( 'Apellido', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
                    <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="account_last_name" id="account_last_name" autocomplete="family-name" value="<?php echo esc_attr( $user->last_name ); ?>" placeholder="Tu apellido" />
                </p>
            </div>
            <div class="clear"></div>

            <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                <label for="account_display_name"><?php esc_html_e( 'Nombre visible', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="account_display_name" id="account_display_name" value="<?php echo esc_attr( $user->display_name ); ?>" />
                <span class="field-hint" style="font-size: 0.75rem; color: #999; margin-top: 0.5rem; display: block;">
                    Así será como se mostrará tu nombre en la sección de tu cuenta y en las valoraciones.
                </span>
            </p>
            <div class="clear"></div>

            <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                <label for="account_email"><?php esc_html_e( 'Correo electrónico', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
                <input type="email" class="woocommerce-Input woocommerce-Input--email input-text" name="account_email" id="account_email" autocomplete="email" value="<?php echo esc_attr( $user->user_email ); ?>" placeholder="tu@email.com" />
            </p>

            <fieldset>
                <legend><?php esc_html_e( 'Cambio de contraseña', 'woocommerce' ); ?></legend>

                <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                    <label for="password_current"><?php esc_html_e( 'Contraseña actual (déjalo en blanco para no cambiarla)', 'woocommerce' ); ?></label>
                    <input type="password" class="woocommerce-Input woocommerce-Input--password input-text" name="password_current" id="password_current" autocomplete="current-password" />
                </p>
                <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                    <label for="password_1"><?php esc_html_e( 'Nueva contraseña (déjalo en blanco para no cambiarla)', 'woocommerce' ); ?></label>
                    <input type="password" class="woocommerce-Input woocommerce-Input--password input-text" name="password_1" id="password_1" autocomplete="new-password" />
                </p>
                <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                    <label for="password_2"><?php esc_html_e( 'Confirmar nueva contraseña', 'woocommerce' ); ?></label>
                    <input type="password" class="woocommerce-Input woocommerce-Input--password input-text" name="password_2" id="password_2" autocomplete="new-password" />
                </p>
            </fieldset>
            <div class="clear"></div>

            <?php do_action( 'woocommerce_edit_account_form' ); ?>

            <p class="form-actions" style="margin-top: 2rem;">
                <?php wp_nonce_field( 'save_account_details', 'save-account-details-nonce' ); ?>
                <button type="submit" class="woocommerce-Button button" name="save_account_details" value="<?php esc_attr_e( 'Guardar cambios', 'woocommerce' ); ?>"><?php esc_html_e( 'Guardar cambios', 'woocommerce' ); ?></button>
                <input type="hidden" name="action" value="save_account_details" />
            </p>

            <?php do_action( 'woocommerce_edit_account_form_end' ); ?>
        </form>
    </div>
</div>

<?php do_action( 'woocommerce_after_edit_account_form' ); ?>
