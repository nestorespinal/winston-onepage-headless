<?php
/**
 * Cart totals
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/cart/cart-totals.php.
 *
 * @package WooCommerce\Templates
 * @version 2.3.6
 */

defined( 'ABSPATH' ) || exit;

?>
<div class="cart_totals <?php echo ( WC()->customer->has_calculated_shipping() ) ? 'calculated_shipping' : ''; ?>">

	<?php do_action( 'woocommerce_before_cart_totals' ); ?>

	<h2 class="cart-totals-title"><?php esc_html_e( 'TOTAL DEL CARRITO', 'woocommerce' ); ?></h2>

	<div class="shop_table shop_table_responsive">

		<!-- Subtotal -->
		<div class="cart-subtotal totals-row">
			<div class="totals-label"><?php esc_html_e( 'SUBTOTAL', 'woocommerce' ); ?></div>
			<div class="totals-value" data-title="<?php esc_attr_e( 'Subtotal', 'woocommerce' ); ?>">
				<?php wc_cart_totals_subtotal_html(); ?>
				<span class="tax-note">(con impuestos)</span>
			</div>
		</div>

		<!-- Shipping -->
		<?php foreach ( WC()->cart->get_coupons() as $code => $coupon ) : ?>
			<div class="cart-discount coupon-<?php echo esc_attr( sanitize_title( $code ) ); ?> totals-row">
				<div class="totals-label"><?php wc_cart_totals_coupon_label( $coupon ); ?></div>
				<div class="totals-value" data-title="<?php echo esc_attr( wc_cart_totals_coupon_label( $coupon, false ) ); ?>"><?php wc_cart_totals_coupon_html( $coupon ); ?></div>
			</div>
		<?php endforeach; ?>

		<?php if ( WC()->cart->needs_shipping() && WC()->cart->show_shipping() ) : ?>

			<?php do_action( 'woocommerce_cart_totals_before_shipping' ); ?>

			<div class="shipping-section">
				<div class="totals-label shipping-label"><?php esc_html_e( 'ENVÍO 1', 'woocommerce' ); ?></div>
				
				<div class="shipping-options">
					<?php wc_cart_totals_shipping_html(); ?>
				</div>

				<?php if ( WC()->customer->has_calculated_shipping() ) : ?>
					<div class="shipping-destination">
						<?php
						$shipping_destination = WC()->countries->get_formatted_address( WC()->customer->get_shipping(), ', ' );
						if ( $shipping_destination ) {
							printf( esc_html__( 'Enviar a %s.', 'woocommerce' ), '<strong>' . esc_html( $shipping_destination ) . '</strong>' );
						}
						?>
					</div>
				<?php endif; ?>

				<button class="shipping-calculator-button change-address" type="button">
					<?php esc_html_e( 'Cambiar dirección', 'woocommerce' ); ?>
				</button>

				<?php if ( ! WC()->customer->has_calculated_shipping() ) : ?>
					<div class="shipping-calculator-form">
						<?php woocommerce_shipping_calculator(); ?>
					</div>
				<?php endif; ?>
			</div>

			<?php do_action( 'woocommerce_cart_totals_after_shipping' ); ?>

		<?php elseif ( WC()->cart->needs_shipping() && 'yes' === get_option( 'woocommerce_enable_shipping_calc' ) ) : ?>

			<div class="shipping-section">
				<div class="totals-label"><?php esc_html_e( 'ENVÍO', 'woocommerce' ); ?></div>
				<div class="totals-value" data-title="<?php esc_attr_e( 'Shipping', 'woocommerce' ); ?>">
					<?php woocommerce_shipping_calculator(); ?>
				</div>
			</div>

		<?php endif; ?>

		<?php foreach ( WC()->cart->get_fees() as $fee ) : ?>
			<div class="fee totals-row">
				<div class="totals-label"><?php echo esc_html( $fee->name ); ?></div>
				<div class="totals-value" data-title="<?php echo esc_attr( $fee->name ); ?>"><?php wc_cart_totals_fee_html( $fee ); ?></div>
			</div>
		<?php endforeach; ?>

		<?php
		if ( wc_tax_enabled() && ! WC()->cart->display_prices_including_tax() ) {
			$taxable_address = WC()->customer->get_taxable_address();
			$estimated_text  = '';

			if ( WC()->customer->is_customer_outside_base() && ! WC()->customer->has_calculated_shipping() ) {
				/* translators: %s location. */
				$estimated_text = sprintf( ' <small>' . esc_html__( '(estimated for %s)', 'woocommerce' ) . '</small>', WC()->countries->estimated_for_prefix( $taxable_address[0] ) . WC()->countries->countries[ $taxable_address[0] ] );
			}

			if ( 'itemized' === get_option( 'woocommerce_tax_total_display' ) ) {
				foreach ( WC()->cart->get_tax_totals() as $code => $tax ) {
					?>
					<div class="tax-rate tax-rate-<?php echo esc_attr( sanitize_title( $code ) ); ?> totals-row">
						<div class="totals-label"><?php echo esc_html( $tax->label ) . $estimated_text; ?></div>
						<div class="totals-value" data-title="<?php echo esc_attr( $tax->label ); ?>"><?php echo wp_kses_post( $tax->formatted_amount ); ?></div>
					</div>
					<?php
				}
			} else {
				?>
				<div class="tax-total totals-row">
					<div class="totals-label"><?php echo esc_html( WC()->countries->tax_or_vat() ) . $estimated_text; ?></div>
					<div class="totals-value" data-title="<?php echo esc_attr( WC()->countries->tax_or_vat() ); ?>"><?php wc_cart_totals_taxes_total_html(); ?></div>
				</div>
				<?php
			}
		}
		?>

		<?php do_action( 'woocommerce_cart_totals_before_order_total' ); ?>

		<!-- Order Total -->
		<div class="order-total totals-row total-row">
			<div class="totals-label total-label"><?php esc_html_e( 'TOTAL', 'woocommerce' ); ?></div>
			<div class="totals-value total-value" data-title="<?php esc_attr_e( 'Total', 'woocommerce' ); ?>">
				<div class="total-price"><?php wc_cart_totals_order_total_html(); ?></div>
				<?php if ( wc_tax_enabled() && WC()->cart->get_taxes_total() > 0 ) : ?>
					<div class="tax-breakdown">(incluye <?php echo wc_price( WC()->cart->get_taxes_total() ); ?> Impuestos)</div>
				<?php endif; ?>
			</div>
		</div>

		<?php do_action( 'woocommerce_cart_totals_after_order_total' ); ?>

	</div>

	<div class="wc-proceed-to-checkout">
		<?php do_action( 'woocommerce_proceed_to_checkout' ); ?>
	</div>

	<?php do_action( 'woocommerce_after_cart_totals' ); ?>

</div>
