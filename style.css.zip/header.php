<?php
/**
 * El Header para nuestro Headless Checkout
 * Este archivo reemplaza el header de Storefront para coincidir con Astro.
 */
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    <div id="menu-overlay" class="menu-overlay"></div>
<?php wp_body_open(); ?>

<header class="header">
    <div class="header-inner">
        <!-- Parte Izquierda: Menú y Buscar -->
        <div class="header-left">
            <button class="burger-menu" id="burger-menu" aria-label="Abrir menú">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="3" y1="6" x2="21" y2="6"></line>
                    <line x1="3" y1="12" x2="21" y2="12"></line>
                    <line x1="3" y1="18" x2="21" y2="18"></line>
                </svg>
            </button>
            
        </div>

        <!-- Parte Central: Logo -->
        <a href="https://winstonandharrystore.com/" class="logo">
            <img src="https://tienda.winstonandharrystore.com/wp-content/uploads/2020/12/logo-w-h-vertical.png" 
                 alt="Winston & Harry Logo" 
                 width="400" height="400" loading="eager" referrerpolicy="no-referrer">
        </a>

        <!-- Parte Derecha: Acciones -->
        <div class="header-right">
            <a href="https://winstonandharrystore.com/mi-cuenta" class="action-btn" aria-label="Mi Perfil">
                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                    <circle cx="12" cy="7" r="4"></circle>
                </svg>
            </a>

            <div class="header-actions-desktop">
                <a href="https://winstonandharrystore.com/lista-de-deseos" class="action-btn" aria-label="Ver Favoritos">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
                    </svg>
                    <span class="fav-count" id="fav-count">0</span>
                </a>
                <button class="action-btn cart-btn-new" id="cart-btn-desktop" aria-label="Carrito">
                    <div class="cart-icon-wrapper">
                        <a href="https://winstonandharrystore.com/carrito" class="action-btn" aria-label="Carrito de compras">
						<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"></path>
                            <path d="M3 6h18"></path>
                            <path d="M16 10a4 4 0 0 1-8 0"></path>
                        </svg>
						</a>
                        <span class="cart-count" id="cart-count"><?php echo WC()->cart->get_cart_contents_count(); ?></span>
                    </div>
                </button>
            </div>
        </div>
    </div>
</header>

<div class="mobile-nav" id="mobile-nav">
    <?php
    wp_nav_menu( array(
        'theme_location' => 'primary',
        'container'      => false,
        'menu_class'     => 'mobile-links',
        'fallback_cb'    => false,
        'depth'          => 2,
        'walker'         => new WH_Walker_Nav_Menu() // Necesitaremos definir esto para las flechas
    ) );
    ?>

    <div class="mobile-actions">
        <a href="https://winstonandharrystore.com/lista-de-deseos" class="mobile-action-item">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>
            <span>Lista de Deseos (<span id="fav-count-mobile">0</span>)</span>
        </a>
        <a href="<?php echo wc_get_cart_url(); ?>" class="mobile-action-item">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"></path><path d="M3 6h18"></path><path d="M16 10a4 4 0 0 1-8 0"></path></svg>
            <span>Carrito (<span><?php echo WC()->cart->get_cart_contents_count(); ?></span>)</span>
        </a>
    </div>

    <div class="menu-footer">
        <a href="https://winstonandharrystore.com/contacto" class="help-link">¿Cómo podemos ayudarle?</a>
    </div>
</div>


<div id="page" class="hfeed site">
    <div id="content" class="site-content" tabindex="-1">
        <div class="container">
        </div>
    </div>
</div>