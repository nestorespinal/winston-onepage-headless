document.addEventListener('DOMContentLoaded', function() {
    // Definición de elementos
    const burgerBtn = document.getElementById("burger-menu");
    const menuOverlay = document.getElementById("menu-overlay");
    const mobileNav = document.getElementById("mobile-nav");
    const header = document.querySelector(".header");
    let lastScrollY = window.scrollY;

    // --- 1. Función Maestra para Abrir/Cerrar Menú ---
    function toggleMenu(open) {
        if (!mobileNav || !menuOverlay) return;
        if (open) {
            mobileNav.classList.add("active");
            menuOverlay.classList.add("active");
            burgerBtn?.classList.add("open");
            document.body.style.overflow = "hidden";
        } else {
            mobileNav.classList.remove("active");
            menuOverlay.classList.remove("active");
            burgerBtn?.classList.remove("open");
            document.body.style.overflow = "";
        }
    }

    // Eventos del Menú
    if (burgerBtn) {
        burgerBtn.addEventListener("click", () => {
            const isOpen = mobileNav?.classList.contains("active");
            toggleMenu(!isOpen);
        });
    }

    if (menuOverlay) {
        menuOverlay.addEventListener("click", () => toggleMenu(false));
    }

    // --- 2. Submenús (Acordeón para móvil) ---
    const submenuToggles = document.querySelectorAll(".submenu-toggle");
    submenuToggles.forEach((toggle) => {
        toggle.addEventListener("click", (e) => {
            e.preventDefault();
            e.stopPropagation();
            const parentLi = toggle.closest(".has-submenu");
            if (!parentLi) return;

            const isOpen = parentLi.classList.contains("open");

            // Cerrar otros submenús abiertos al abrir uno nuevo
            document.querySelectorAll(".has-submenu").forEach((li) => {
                li.classList.remove("open");
                li.querySelector(".submenu-toggle")?.setAttribute("aria-expanded", "false");
            });

            if (!isOpen) {
                parentLi.classList.add("open");
                toggle.setAttribute("aria-expanded", "true");
            }
        });
    });

    // --- 3. Favoritos (Sincronización con Astro vía LocalStorage) ---
    function updateFavCount() {
        const countSpans = [
            document.getElementById("fav-count"),
            document.getElementById("fav-count-mobile"),
        ];
        try {
            const favorites = JSON.parse(localStorage.getItem("wh_favorites") || "[]");
            const count = favorites.length;
            countSpans.forEach((span) => {
                if (!span) return;
                const isMobile = span.id.includes("mobile");
                if (count > 0) {
                    span.textContent = count.toString();
                    span.style.display = isMobile ? "inline" : "flex";
                } else {
                    span.style.display = "none";
                    if (isMobile) { 
                        span.textContent = "0"; 
                        span.style.display = "inline";
                    }
                }
            });
        } catch (e) { console.error("Error al leer favoritos", e); }
    }

    // Fix Cart Visibility
    function checkCartVisibility() {
        document.querySelectorAll('.cart-count').forEach(span => {
            const count = parseInt(span.textContent || '0', 10);
            if(count > 0) {
                span.style.display = 'flex';
            } else {
                span.style.display = 'none';
            }
        });
    }

    // Observador para cuando WooCommerce refresque los fragmentos del carrito
    const cartObserver = new MutationObserver(() => checkCartVisibility());
    document.querySelectorAll('.cart-count').forEach(span => {
        cartObserver.observe(span, { characterData: true, childList: true, subtree: true });
    });

    // --- 4. Control de Scroll (Ocultar/Mostrar Header) ---
    window.addEventListener("scroll", () => {
        // No ocultar si el menú móvil está abierto
        if (mobileNav?.classList.contains("active")) return;

        if (window.scrollY > lastScrollY && window.scrollY > 100) {
            header?.classList.add("header-hidden");
            document.body.classList.add("is-header-hidden");
        } else {
            header?.classList.remove("header-hidden");
            document.body.classList.remove("is-header-hidden");
        }
        lastScrollY = window.scrollY;
    });

    // Inicializar funciones al cargar
    updateFavCount();
    checkCartVisibility();
});

const overlay = document.getElementById('menu-overlay');
const drawer = document.querySelector('.mobile-menu-drawer');

// Al abrir el menú, añade 'active' al overlay y 'open' al drawer
// Al hacer click en el overlay:
overlay.addEventListener('click', () => {
    drawer.classList.remove('open');
    overlay.classList.remove('active');
});
